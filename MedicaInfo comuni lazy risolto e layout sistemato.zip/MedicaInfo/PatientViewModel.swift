import Foundation
import SwiftUI
import CoreData
import Combine

class PatientViewModel: ObservableObject {
    @Published var patient: Patient
    @Published var noteText: String
    @Published var selectedComuneNascita: Comune?
    
    @Published var comuni: [Comune] = []
    private var cancellables: Set<AnyCancellable> = []

    init(patient: Patient) {
        self.patient = patient
        self.noteText = patient.nota ?? ""
        loadComuni()
        self.selectedComuneNascita = comuni.first { $0.nome == patient.birthPlace }
    }

    func updateNoteText() {
        patient.nota = noteText
        saveContext()
        noteText = ""
    }

    private func saveContext() {
        do {
            try patient.managedObjectContext?.save()
        } catch {
            print("Failed to save context: \(error)")
        }
    }

    func loadComuni() {
        let loader = DataLoader()
        loader.loadComuni { [weak self] comuni in
            self?.comuni = comuni
            // Imposta il comune selezionato dopo che i comuni sono stati caricati
            self?.selectedComuneNascita = comuni.first { $0.nome == self?.patient.birthPlace }
        }
    }
}
