import SwiftUI
import CoreData

struct PatientCardView: View {
    var patient: MedicalPatient

    var body: some View {
        HStack(alignment: .center, spacing: 16) {
            Image(systemName: "person.crop.circle.fill.badge.checkmark")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(.blue)
                .padding(.leading, 8)
            
            VStack(alignment: .leading, spacing: 6) {
                Text("\(patient.name ?? "Nome non disponibile") \(patient.surname ?? "Cognome non disponibile")")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                HStack(spacing: 4) {
                    Image(systemName: "calendar")
                        .foregroundColor(.blue)
                    Text("Data di nascita:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text(patient.birthDate != nil ? DateFormatter.localizedString(from: patient.birthDate!, dateStyle: .medium, timeStyle: .none) : "N/A")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                HStack(spacing: 4) {
                    Image(systemName: "phone")
                        .foregroundColor(.blue)
                    Text("Telefono:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text(patient.tel ?? "N/A")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
        }
        .padding()
        .background(
            LinearGradient(gradient: Gradient(colors: [Color.white, Color(.systemGray6)]), startPoint: .top, endPoint: .bottom)
        )
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 5)
        .padding(.vertical, 8)
        .padding(.horizontal)
    }
}

struct PatientCardView_Previews: PreviewProvider {
    static var previews: some View {
        // Context di CoreData per la preview
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

        // Fetch request per ottenere un paziente esistente
        let fetchRequest: NSFetchRequest<MedicalPatient> = MedicalPatient.fetchRequest()
        fetchRequest.fetchLimit = 1

        // Prova a ottenere un paziente esistente, altrimenti crea un paziente temporaneo per la preview
        let patient: MedicalPatient
        if let fetchedPatients = try? context.fetch(fetchRequest), let firstPatient = fetchedPatients.first {
            patient = firstPatient
        } else {
            // Crea un paziente temporaneo per la preview se non ci sono pazienti in CoreData
            let newPatient = MedicalPatient(context: context)
            newPatient.name = "John"
            newPatient.surname = "Doe"
            newPatient.birthDate = Date()
            newPatient.tel = "1234567890"
            patient = newPatient
        }

        return PatientCardView(patient: patient)
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
