import SwiftUI
import CoreData

struct DetailView: View {
    @FetchRequest(
        entity: Patient.entity(),
        sortDescriptors: [NSSortDescriptor(keyPath: \Patient.name, ascending: true)]
    ) private var patients: FetchedResults<Patient>
    
    @State private var expandedPatientId: NSManagedObjectID?
    @State private var searchText: String = ""
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) var presentationMode
    
    @State private var selectedPatient: Patient?
    @State private var isSearchVisible: Bool = false
    var onDeleteAllPatients: () -> Void
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.systemGray6).edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 0) {
                    if isSearchVisible {
                        SearchBar(text: $searchText)
                            .transition(.move(edge: .top))
                            .padding(.horizontal)
                    }
                    
                    List {
                        ForEach(patients.filter { patient in
                            searchText.isEmpty || patient.name?.contains(searchText) == true
                        }) { patient in
                            NavigationLink(value: patient) {
                                PatientCardView(patient: patient)
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(10)
                                    .shadow(radius: 2)
                                    .padding(.vertical, 4)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        .listRowBackground(Color(.systemGray6))
                        .listRowSeparator(.hidden)
                    }
                    .listStyle(PlainListStyle())
                    
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            Image(systemName: "chevron.left")
                                .foregroundColor(.blue)
                                .bold()
                                .font(.system(size: 24))
                        }
                        Spacer()
                        
                        if !patients.isEmpty {
                            Button(action: {
                                onDeleteAllPatients()
                            }) {
                                Image(systemName: "trash")
                                    .foregroundColor(.red)
                                    .font(.system(size: 24))
                            }
                        }
                        
                        Spacer()
                        
                        Button(action: {
                            withAnimation {
                                isSearchVisible.toggle()
                            }
                        }) {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(.blue)
                                .font(.system(size: 24))
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: -5)
                }
            }
            .navigationDestination(for: Patient.self) { patient in
                PatientDetailView(patient: patient, context: viewContext)
                    .navigationBarTitleDisplayMode(.inline)
            }
            .navigationBarTitle("")
            .navigationBarHidden(true)
        }
    }
}
